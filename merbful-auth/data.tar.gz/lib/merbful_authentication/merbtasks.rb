namespace :merbful_authentication do
  desc "Do something for merbful_authentication"
  task :default do
    puts "merbful_authentication doesn't do anything"
  end
end